# JARVIS Offline Android project — phone-only build

## Important honesty note
This starter app is a native Android app with basic offline commands, local saved memory, and Android text-to-speech. It is **not yet a full local LLM**: no GGUF/model weights are bundled. The project is a buildable starting point; integrating a large offline language model is a separate step and requires extra storage/RAM and native runtime integration.

## Easiest phone-only way to build an APK
This project includes a GitHub Actions workflow that builds a debug APK in the cloud. You do not need Termux or Android Studio on your phone.

1. Sign in to GitHub or create an account.
2. Create a new repository, e.g. `jarvis-android`.
3. Upload the contents of this ZIP into the repository (not the ZIP file itself). On GitHub mobile/web, use **Add file → Upload files** and upload the extracted files. If your phone cannot extract ZIPs, use a file manager that can extract ZIP files.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab.
6. Select **Build JARVIS APK**, then **Run workflow** if it has not started automatically.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run and download the artifact named `JARVIS-debug-APK`.
9. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
10. Open the APK on your phone and allow installation from that source if Android asks.

## Current commands
- `what time is it`
- `what is the date`
- `remember that my favourite colour is blue`
- `what do you remember`
- `clear memory`
- `open settings`
- `open YouTube`
- `open camera`
- `open browser`

Memory is stored locally in this app's private preferences. Removing the app may remove that memory.

## Offline notes
The listed commands and saved memory work offline. Android text-to-speech works offline only if an offline voice is installed in Android's Text-to-speech settings. Opening web pages requires internet. Camera and app launching depend on Android/device restrictions.

## Signing and publishing
This debug APK is for testing. For Google Play publishing, create a signed release build and follow current Play Console requirements. Do not publish the debug APK as a production release.
