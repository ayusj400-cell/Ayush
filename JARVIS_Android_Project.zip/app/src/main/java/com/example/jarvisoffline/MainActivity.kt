package com.example.jarvisoffline

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var conversation: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }
    private val history = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addLine("JARVIS", "Hello! I'm JARVIS. I'm running in offline basic-assistant mode. Try “what time is it”, “remember that my favourite colour is blue”, or “open settings”.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            setBackgroundColor(Color.rgb(8, 15, 30))
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 28f
            setTextColor(Color.rgb(91, 203, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL ASSISTANT • OFFLINE"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(14))
        }
        conversation = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val scroll = ScrollView(this).apply {
            addView(conversation)
            setBackgroundColor(Color.rgb(17, 29, 49))
        }
        input = EditText(this).apply {
            hint = "Type a command…"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val send = Button(this).apply {
            text = "SEND"
            setOnClickListener { submit() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, dp(54), 1f))
            addView(send, LinearLayout.LayoutParams(dp(94), dp(54)))
        }

        val quickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        quickRow.addView(quickButton("TIME") { runCommand("what time is it") }, weightedButton())
        quickRow.addView(quickButton("MEMORY") { runCommand("what do you remember") }, weightedButton())
        quickRow.addView(quickButton("SETTINGS") { runCommand("open settings") }, weightedButton())

        root.addView(title)
        root.addView(subtitle)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row, LinearLayout.LayoutParams(-1, dp(58)))
        root.addView(quickRow, LinearLayout.LayoutParams(-1, dp(52)))
        setContentView(root)

        send.setTextColor(Color.rgb(8, 15, 30))
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
        }
    }

    private fun quickButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 10f
        setOnClickListener { action() }
    }

    private fun weightedButton() = LinearLayout.LayoutParams(0, dp(48), 1f)

    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        runCommand(text)
    }

    private fun runCommand(message: String) {
        addLine("YOU", message)
        val answer = respond(message)
        addLine("JARVIS", answer)
        if (ttsReady) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun respond(message: String): String {
        val text = message.lowercase(Locale.ROOT).trim()

        if (text in listOf("exit", "quit", "goodbye")) {
            return "I'll be here when you need me."
        }
        if (text.contains("what time") || text == "time") {
            return "The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        }
        if (text.contains("what is the date") || text == "date" || text == "today's date") {
            return "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
        }
        if (text.startsWith("remember that ")) {
            val fact = message.substringAfter("remember that ", "").trim()
            if (fact.isNotBlank()) {
                val old = prefs.getString("facts", "") ?: ""
                prefs.edit().putString("facts", (old + "\n" + fact).trim()).apply()
                return "Saved to this phone's local memory: $fact"
            }
        }
        if (text.contains("what do you remember") || text == "memory") {
            val facts = prefs.getString("facts", "") ?: ""
            return if (facts.isBlank()) "I haven't saved any memories yet. Say: remember that my favourite colour is blue." else "Here's what I remember:\n$facts"
        }
        if (text == "forget everything" || text == "clear memory") {
            prefs.edit().remove("facts").apply()
            return "Saved memories cleared from this app."
        }
        if (text.contains("what is your name") || text == "who are you") {
            return "I'm JARVIS, your personal Android assistant."
        }
        if (text.contains("how are you") || text == "status") {
            return "All local assistant systems are ready. My advanced language model is not installed yet."
        }
        if (text == "open settings" || text == "phone settings") {
            return launchAction("settings") { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        if (text == "open youtube" || text == "launch youtube") {
            return launchAction("YouTube") {
                val appIntent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (appIntent != null) startActivity(appIntent)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            }
        }
        if (text == "open camera" || text == "launch camera") {
            return launchAction("camera") {
                startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            }
        }
        if (text == "open browser" || text == "open google") {
            return launchAction("browser") {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
            }
        }

        val key = when {
            text.contains("hello") || text == "hi" || text == "hey jarvis" ->
                listOf("Hello! I'm listening.", "Hey there. What can I help you with?")
            text.contains("how are you") -> listOf("I'm doing well. Ready to help.")
            text.contains("thank") -> listOf("You're welcome.")
            text.contains("joke") -> listOf("Why did the computer get cold? It left its Windows open.")
            else -> emptyList()
        }
        if (key.isNotEmpty()) return key.random()

        return "I can handle basic offline commands right now. A full conversational offline AI model isn't bundled yet. Try asking for the time, saving a memory, or opening an app."
    }

    private fun launchAction(label: String, action: () -> Unit): String {
        return try {
            action()
            "Opening $label."
        } catch (_: Exception) {
            "I couldn't open $label. Check whether a compatible app is installed."
        }
    }

    private fun addLine(who: String, message: String) {
        conversation.append("$who: $message\n\n")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts.language = Locale.getDefault()
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
